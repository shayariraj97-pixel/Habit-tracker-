// Runs after `npx cap add android`: copies our native widget code, icons and signing into the generated project.
const fs = require('fs');
const path = require('path');

const root = process.cwd();
const main = path.join(root, 'android', 'app', 'src', 'main');
const javaDir = path.join(main, 'java', 'com', 'jee', 'tracker');
const resDir = path.join(main, 'res');

// 1. Java sources (MainActivity is replaced so the JeeWidget plugin gets registered)
fs.mkdirSync(javaDir, { recursive: true });
for (const f of fs.readdirSync(path.join(root, 'native', 'java'))) {
  fs.copyFileSync(path.join(root, 'native', 'java', f), path.join(javaDir, f));
}

// 2. Remove default launcher icons / splash variants that would override ours
for (const d of fs.readdirSync(resDir)) {
  const full = path.join(resDir, d);
  if (d.startsWith('mipmap-')) {
    for (const f of fs.readdirSync(full)) {
      if (f.startsWith('ic_launcher')) fs.rmSync(path.join(full, f), { force: true });
    }
  }
}

// 3. Resources: layouts, widget xml, icons, colours
fs.cpSync(path.join(root, 'native', 'res'), resDir, { recursive: true, force: true });

// 4. Manifest: register the three widget receivers
const mfPath = path.join(main, 'AndroidManifest.xml');
let mf = fs.readFileSync(mfPath, 'utf8');
if (!mf.includes('QuoteWidgetProvider')) {
  const rec = (cls, xml) => `
        <receiver android:name=".${cls}" android:exported="true">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/${xml}" />
        </receiver>`;
  const block = rec('QuoteWidgetProvider', 'quote_widget_info') +
                rec('HabitsWidgetProvider', 'habits_widget_info') +
                rec('SubjectsWidgetProvider', 'subjects_widget_info') + '\n    ';
  mf = mf.replace('</application>', block + '</application>');
  fs.writeFileSync(mfPath, mf);
}

// 4b. App label
const strPath = path.join(resDir, 'values', 'strings.xml');
if (fs.existsSync(strPath)) {
  let s = fs.readFileSync(strPath, 'utf8');
  s = s.replace(/(<string name="app_name">)[^<]*(<\/string>)/, '$1JEE Tracker$2')
       .replace(/(<string name="title_activity_main">)[^<]*(<\/string>)/, '$1JEE Tracker$2');
  fs.writeFileSync(strPath, s);
}

// 5. Fixed signing key (same key every build => new APK installs over the old one, data is kept)
const gradlePath = path.join(root, 'android', 'app', 'build.gradle');
let g = fs.readFileSync(gradlePath, 'utf8');
if (!g.includes('jeeFixed')) {
  g += `

android {
    signingConfigs {
        jeeFixed {
            storeFile file("$rootDir/../debug.keystore")
            storePassword System.getenv("KS_PASS") ?: "android"
            keyAlias System.getenv("KS_ALIAS") ?: "androiddebugkey"
            keyPassword System.getenv("KS_KEY_PASS") ?: "android"
        }
    }
    buildTypes {
        debug { signingConfig signingConfigs.jeeFixed }
        release { signingConfig signingConfigs.jeeFixed }
    }
}
`;
  fs.writeFileSync(gradlePath, g);
}
console.log('Android project patched OK');
