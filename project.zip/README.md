# JEE 2028 Tracker (Android + home-screen widgets)

Web app (www/index.html) wrapped with Capacitor, plus native Android code in `native/`:
- JeeWidgetPlugin - receives the app data and refreshes widgets
- 3 widgets: Daily Fuel quotes (flips every 7 s), Habit consistency graph, Subjects progress
- icons from your logo, fixed signing key (debug.keystore)

GitHub Actions (`.github/workflows/build.yml`) builds the APK on every push.
Download it from the Releases page or Actions -> latest run -> Artifacts.

To change the app: edit `www/index.html`, commit, wait ~6 minutes, install the new APK.
