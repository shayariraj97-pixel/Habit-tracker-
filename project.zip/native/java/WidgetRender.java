package com.jee.tracker;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.*;
import android.os.Bundle;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import org.json.JSONArray;
import org.json.JSONObject;

/** Draws widget bitmaps (graph, subject rings, manga quote card) from the JSON saved by the app. */
final class WidgetRender {
    static final String PREFS = "jee_widget";
    static final int[] GC = {Color.WHITE, Color.parseColor("#FF8A3D"), Color.parseColor("#22D3C5"), Color.parseColor("#FF4D5E")};
    static final String[] GN = {"Study", "Fitness", "Mind", "Bad"};

    static JSONObject data(Context c) {
        try {
            String s = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("data", null);
            return s == null ? new JSONObject() : new JSONObject(s);
        } catch (Exception e) { return new JSONObject(); }
    }

    static void updateAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] a = m.getAppWidgetIds(new ComponentName(c, HabitsWidgetProvider.class));
        if (a.length > 0) new HabitsWidgetProvider().onUpdate(c, m, a);
        int[] b = m.getAppWidgetIds(new ComponentName(c, SubjectsWidgetProvider.class));
        if (b.length > 0) new SubjectsWidgetProvider().onUpdate(c, m, b);
    }

    /** widget size in pixels from its options (capped so bitmaps stay small) */
    static int[] size(Context c, AppWidgetManager m, int id, int dw, int dh) {
        Bundle o = m.getAppWidgetOptions(id);
        float d = c.getResources().getDisplayMetrics().density;
        int w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0);
        int h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        int pw = w > 0 ? (int) (w * d) : dw, ph = h > 0 ? (int) (h * d) : dh;
        long px = (long) pw * ph;
        if (px > 700000L) { double s = Math.sqrt(700000.0 / px); pw = (int) (pw * s); ph = (int) (ph * s); }
        return new int[]{Math.max(pw, 300), Math.max(ph, 150)};
    }

    static PendingIntent open(Context c) {
        Intent i = new Intent(c, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static Paint paint(int color, float size, boolean bold) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color); p.setTextSize(size);
        p.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        return p;
    }

    // ------------------------------------------------ habit consistency graph
    static Bitmap graph(JSONObject d, int w, int h) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b); c.drawColor(Color.BLACK);
        float u = h / 300f;
        Paint t = paint(Color.WHITE, 15 * u, true);
        c.drawText("HABIT CONSISTENCY", 18 * u, 28 * u, t);
        Paint r = paint(Color.parseColor("#8FA0D0"), 13 * u, false);
        r.setTextAlign(Paint.Align.RIGHT);
        c.drawText(d.optString("mn", "") + "  ·  today " + d.optInt("done", 0) + "/" + d.optInt("tot", 0), w - 18 * u, 28 * u, r);
        float L = 18 * u, R = w - 18 * u, T = 46 * u, B = h - 44 * u;
        Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG); grid.setColor(Color.parseColor("#1F1F24")); grid.setStrokeWidth(1.2f * u);
        for (int i = 0; i <= 2; i++) { float y = B - (B - T) * i / 2f; c.drawLine(L, y, R, y, grid); }
        int n = Math.max(2, d.optInt("n", 30));
        JSONArray g = d.optJSONArray("g");
        int[] order = {3, 0, 1, 2};
        if (g != null) for (int k : order) {
            JSONArray a = g.optJSONArray(k);
            if (a == null || a.length() == 0) continue;
            Paint lp = new Paint(Paint.ANTI_ALIAS_FLAG); lp.setColor(GC[k]); lp.setStyle(Paint.Style.STROKE);
            lp.setStrokeWidth(2.6f * u); lp.setStrokeCap(Paint.Cap.ROUND); lp.setStrokeJoin(Paint.Join.ROUND);
            Paint dp = new Paint(Paint.ANTI_ALIAS_FLAG); dp.setColor(GC[k]);
            Path p = new Path();
            for (int i = 0; i < a.length(); i++) {
                float x = L + (R - L) * i / (n - 1f), y = B - (B - T) * (float) a.optDouble(i, 0) / 100f;
                if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
            }
            c.drawPath(p, lp);
            for (int i = 0; i < a.length(); i++) {
                float x = L + (R - L) * i / (n - 1f), y = B - (B - T) * (float) a.optDouble(i, 0) / 100f;
                c.drawCircle(x, y, 2.4f * u, dp);
            }
        }
        Paint lg = paint(Color.parseColor("#C9D2F0"), 12 * u, false);
        float x = L;
        for (int k = 0; k < 4; k++) {
            Paint dp = new Paint(Paint.ANTI_ALIAS_FLAG); dp.setColor(GC[k]);
            c.drawCircle(x + 5 * u, h - 20 * u, 5 * u, dp);
            c.drawText(GN[k], x + 16 * u, h - 15.5f * u, lg);
            x += 16 * u + lg.measureText(GN[k]) + 22 * u;
        }
        return b;
    }

    // ------------------------------------------------ subjects progress rings
    static Bitmap subjects(JSONObject d, int w, int h) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b); c.drawColor(Color.BLACK);
        float u = h / 300f;
        long exam = d.optLong("exam", 0);
        long days = exam > 0 ? (long) Math.ceil((exam - System.currentTimeMillis()) / 86400000.0) : 0;
        c.drawText("JEE 2028", 18 * u, 28 * u, paint(Color.WHITE, 15 * u, true));
        Paint r = paint(Color.parseColor("#8FA0D0"), 13 * u, false);
        r.setTextAlign(Paint.Align.RIGHT);
        c.drawText(Math.max(days, 0) + " days left  ·  streak " + d.optInt("streak", 0), w - 18 * u, 28 * u, r);
        String[] names = {"Physics", "Chemistry", "Maths"};
        String[] keys = {"phy", "chem", "math"};
        int[] cols = {Color.parseColor("#4F8CFF"), Color.parseColor("#34D399"), Color.parseColor("#F59E0B")};
        float radius = Math.min(w / 7.2f, (h - 120 * u) / 2f);
        float cy = 52 * u + radius + 6 * u;
        for (int i = 0; i < 3; i++) {
            float cx = w * (i + 0.5f) / 3f, sw = radius * 0.24f, rr = radius - sw / 2f;
            Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG); bg.setStyle(Paint.Style.STROKE); bg.setStrokeWidth(sw); bg.setColor(Color.parseColor("#1F1F24"));
            Paint fg = new Paint(Paint.ANTI_ALIAS_FLAG); fg.setStyle(Paint.Style.STROKE); fg.setStrokeWidth(sw); fg.setColor(cols[i]); fg.setStrokeCap(Paint.Cap.ROUND);
            RectF o = new RectF(cx - rr, cy - rr, cx + rr, cy + rr);
            c.drawCircle(cx, cy, rr, bg);
            int pct = Math.max(0, Math.min(100, d.optInt(keys[i], 0)));
            if (pct > 0) c.drawArc(o, -90, 360f * pct / 100f, false, fg);
            Paint pt = paint(Color.WHITE, radius * 0.55f, true); pt.setTextAlign(Paint.Align.CENTER);
            c.drawText(pct + "%", cx, cy + radius * 0.19f, pt);
            Paint nm = paint(Color.parseColor("#C9D2F0"), 13 * u, false); nm.setTextAlign(Paint.Align.CENTER);
            c.drawText(names[i], cx, cy + radius + 24 * u, nm);
        }
        return b;
    }

    // ------------------------------------------------ manga "Gun Park" quote card
    static Bitmap manga(int w, int h) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b); c.drawColor(Color.WHITE);
        float s = h * 0.233f;
        Paint band = new Paint(Paint.ANTI_ALIAS_FLAG);
        band.setColor(Color.parseColor("#FFD9D0")); drawBand(c, band, w * 0.46f, w * 0.62f, s, h);
        band.setColor(Color.parseColor("#F0705A")); drawBand(c, band, w * 0.62f, w * 0.70f, s, h);
        float u = h / 300f;
        String[] q = Quotes.ALL[9];
        TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        tp.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        int tw = (int) (w * 0.78f);
        float size = h * 0.2f; StaticLayout lay;
        while (true) {
            tp.setTextSize(size);
            lay = new StaticLayout(q[1].toUpperCase(), tp, tw, Layout.Alignment.ALIGN_CENTER, 1f, 0f, false);
            if (lay.getHeight() <= h * 0.58f || size < 14 * u) break;
            size -= 2 * u;
        }
        float tx = (w - tw) / 2f, ty = h * 0.07f + (h * 0.6f - lay.getHeight()) / 2f;
        TextPaint st = new TextPaint(tp); st.setStyle(Paint.Style.STROKE); st.setStrokeWidth(Math.max(4f, size * 0.12f)); st.setColor(Color.parseColor("#141414")); st.setStrokeJoin(Paint.Join.ROUND);
        TextPaint fl = new TextPaint(tp); fl.setStyle(Paint.Style.FILL); fl.setColor(Color.WHITE);
        c.save(); c.translate(tx, ty);
        new StaticLayout(q[1].toUpperCase(), st, tw, Layout.Alignment.ALIGN_CENTER, 1f, 0f, false).draw(c);
        new StaticLayout(q[1].toUpperCase(), fl, tw, Layout.Alignment.ALIGN_CENTER, 1f, 0f, false).draw(c);
        c.restore();
        Paint a = paint(Color.WHITE, h * 0.075f, true); a.setTextAlign(Paint.Align.CENTER);
        Paint ao = new Paint(a); ao.setStyle(Paint.Style.STROKE); ao.setStrokeWidth(h * 0.02f); ao.setColor(Color.parseColor("#141414"));
        c.drawText(q[2], w / 2f, h * 0.84f, ao); c.drawText(q[2], w / 2f, h * 0.84f, a);
        Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
        for (int i = 0; i < 5; i++) { dot.setColor(i == 2 ? Color.parseColor("#F0705A") : Color.parseColor("#C8C8C8")); c.drawCircle(w / 2f + (i - 2) * 16 * u, h * 0.94f, 3.4f * u, dot); }
        return b;
    }

    private static void drawBand(Canvas c, Paint p, float x1, float x2, float s, float h) {
        Path path = new Path();
        path.moveTo(x1 + s, 0); path.lineTo(x2 + s, 0); path.lineTo(x2 - s, h); path.lineTo(x1 - s, h); path.close();
        c.drawPath(path, p);
    }
}
