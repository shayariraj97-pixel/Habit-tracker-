package com.jee.tracker;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.os.Bundle;
import android.widget.RemoteViews;

/** Daily Fuel widget: all quotes inside a ViewFlipper that auto-flips every 7 seconds. */
public class QuoteWidgetProvider extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) {
            int[] sz = WidgetRender.size(c, m, id, 700, 350);
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_quote);
            rv.removeAllViews(R.id.flipper);
            for (String[] q : Quotes.ALL) {
                RemoteViews item;
                if (q[0].equals("manga")) {
                    item = new RemoteViews(c.getPackageName(), R.layout.widget_quote_item_img);
                    item.setImageViewBitmap(R.id.qimg, WidgetRender.manga(Math.min(sz[0], 800), Math.min(sz[1], 450)));
                } else {
                    int[] col = Quotes.colors(q[0]);
                    item = new RemoteViews(c.getPackageName(), R.layout.widget_quote_item);
                    item.setInt(R.id.qbg, "setBackgroundColor", col[0]);
                    item.setTextViewText(R.id.qtext, q[1]);
                    item.setTextColor(R.id.qtext, col[1]);
                    item.setTextViewText(R.id.qauthor, q[2]);
                    item.setTextColor(R.id.qauthor, col[2]);
                }
                rv.addView(R.id.flipper, item);
            }
            rv.setOnClickPendingIntent(R.id.root, WidgetRender.open(c));
            m.updateAppWidget(id, rv);
        }
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) {
        onUpdate(c, m, new int[]{id});
    }
}
