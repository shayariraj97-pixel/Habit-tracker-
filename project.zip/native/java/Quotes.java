package com.jee.tracker;

import android.graphics.Color;

/** Same 18 quotes as the app's Daily Fuel card: {style, text, author}. */
final class Quotes {
    static final String[][] ALL = {
        {"hero", "If you failed as a Hero\nComeback as a Villain", "– Karn –"},
        {"paper", "No Results? Keep Working.\nBad Results? Keep Working.\nGood Results? Keep Working.", ""},
        {"ravan", "When ego combined with knowledge,\neven the gods tremble.", "– Ravan –"},
        {"paper", "You can only win when your\nmind is stronger than your\nemotions.", ""},
        {"bat", "You're not brave. Men are brave.", "Batman – Batman v Superman"},
        {"pain", "Pain doesn't hurt you,\nIt builds you.", ""},
        {"fog", "Ego never accept defeat !", ""},
        {"shiva", "“Fear nothing. Even death bows to the one who walks with Shiva..”", "– Har Har Mahadev –"},
        {"mono", "WARRIORS die with EGO,\nbut NEVER accept DEFEAT.", ""},
        {"manga", "In the end,\nRESULTS\nare what matter.", "— GUN PARK"},
        {"stoic", "If you control your mind, you can change your life.", "– stoicsandstoicism –"},
        {"prime", "It's time to\nRe-enter In My Prime 💀", ""},
        {"paper", "“He will win who knows\nwhen to fight\nand when not to fight”", "– Sun Tzu –"},
        {"paper", "“Each one of us is responsible\nto everyone\nand for everything.”", "– Fyodor Dostoevsky –"},
        {"paper", "“Whoever fights monsters\nshould see to it that\nin the process\nhe does not become a monster.”", "– Friedrich Nietzsche –"},
        {"paper", "“The darker the night,\nthe brighter the stars;\nthe deeper the grief,\nthe closer to God”", "– Fyodor Dostoevsky –"},
        {"paper", "“He who has a why to live\ncan bear almost any how”", "– Friedrich Nietzsche –"},
        {"paper", "“Hell is empty,\ncuz all the devils are here.”", "– William Shakespeare –"}
    };

    /** returns {background, text, author} colours for a style */
    static int[] colors(String s) {
        switch (s) {
            case "hero":  return new int[]{Color.parseColor("#0E2A35"), Color.WHITE, Color.parseColor("#FFD23F")};
            case "paper": return new int[]{Color.parseColor("#BDB8B0"), Color.parseColor("#161616"), Color.parseColor("#222222")};
            case "ravan": return new int[]{Color.parseColor("#2D0E08"), Color.WHITE, Color.parseColor("#FFD23F")};
            case "bat":   return new int[]{Color.parseColor("#1E272B"), Color.WHITE, Color.parseColor("#CFD8DC")};
            case "pain":  return new int[]{Color.parseColor("#26262A"), Color.WHITE, Color.parseColor("#D4A84B")};
            case "fog":   return new int[]{Color.parseColor("#25282D"), Color.WHITE, Color.parseColor("#D4A84B")};
            case "shiva": return new int[]{Color.parseColor("#16232B"), Color.WHITE, Color.parseColor("#FFFFFF")};
            case "mono":  return new int[]{Color.parseColor("#0C0C0E"), Color.WHITE, Color.parseColor("#E9E2D0")};
            case "stoic": return new int[]{Color.parseColor("#4A769A"), Color.WHITE, Color.WHITE};
            default:      return new int[]{Color.parseColor("#1C1C1D"), Color.parseColor("#F5F5F7"), Color.parseColor("#E9E9ED")};
        }
    }
}
