package com.jee.tracker;

import android.graphics.Bitmap;
import org.json.JSONObject;

public class HabitsWidgetProvider extends ImageWidgetProvider {
    @Override Bitmap render(JSONObject d, int w, int h) { return WidgetRender.graph(d, w, h); }
}
