package com.jee.tracker;

import android.graphics.Bitmap;
import org.json.JSONObject;

public class SubjectsWidgetProvider extends ImageWidgetProvider {
    @Override Bitmap render(JSONObject d, int w, int h) { return WidgetRender.subjects(d, w, h); }
}
