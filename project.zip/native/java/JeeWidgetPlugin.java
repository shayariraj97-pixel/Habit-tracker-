package com.jee.tracker;

import android.content.Context;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Receives the app's JSON from index.html (Capacitor.Plugins.JeeWidget.save) and refreshes widgets. */
@CapacitorPlugin(name = "JeeWidget")
public class JeeWidgetPlugin extends Plugin {
    @PluginMethod
    public void save(PluginCall call) {
        String data = call.getString("data");
        if (data == null) { call.reject("no data"); return; }
        Context c = getContext();
        c.getSharedPreferences(WidgetRender.PREFS, Context.MODE_PRIVATE).edit().putString("data", data).apply();
        WidgetRender.updateAll(c);
        call.resolve();
    }
}
