package com.jee.tracker;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.RemoteViews;
import org.json.JSONObject;

/** Base for widgets that are one drawn bitmap (graph, subjects). */
abstract class ImageWidgetProvider extends AppWidgetProvider {
    abstract Bitmap render(JSONObject data, int w, int h);

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) {
            int[] sz = WidgetRender.size(c, m, id, 900, 450);
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_image);
            rv.setImageViewBitmap(R.id.img, render(WidgetRender.data(c), sz[0], sz[1]));
            rv.setOnClickPendingIntent(R.id.root, WidgetRender.open(c));
            m.updateAppWidget(id, rv);
        }
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) {
        onUpdate(c, m, new int[]{id});
    }
}
